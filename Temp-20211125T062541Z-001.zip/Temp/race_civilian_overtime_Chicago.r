library(dplyr)

# https://www.chicagotribune.com/politics/ct-census-2020-chicago-illinois-20210812-pdmlgrdrsbaqnlrwl4etgd2y7a-story.html
# https://home.chicagopolice.org/statistics-data/statistical-reports/annual-reports/

df <- data.frame(time = as.Date(c("2020-12-01", "2020-12-01", "2020-12-01")),
                 race = c("White", "Black", "Hispanic"),
                 Race = c("White", "Black", "Hispanic"),
                 group = c("Chicago pop.", "Chicago pop.","Chicago pop."),
                 Group = c("Chicago pop.", "Chicago pop.", "Chicago pop."),
                 value = c(0.314, 0.287, 0.299))

df2 <- data.frame(time = as.Date(c("2017-12-01", "2017-12-01", "2017-12-01")),
                  race = c("White", "Black", "Hispanic"),
                  Race = c("White", "Black", "Hispanic"),
                  group = c("CPD personnel records", "CPD personnel records","CPD personnel records"),
                  Group = c("CPD personnel records", "CPD personnel records", "CPD personnel records"),
                  value = c(6246 / 12474, 2611 / 12474, 3110 / 12474))

composition.race2 <- composition.race %>% filter(Group != "CPD reports") %>% bind_rows(df, df2)

ggplot(composition.race2[between(time, ymd('1969-12-01'), ymd('2021-12-01')) &
                          race %in% c('Black', 'White', 'Hispanic'),
                        ],
       aes(x = time,
           y = value,
           shape = Group
       )
) +
  geom_point(aes(color = Race),
             fill = NA,
             size = 3
  ) +
  geom_line(aes(color = Race),
            data = composition.race2[
              between(time, ymd('1970-12-01'), ymd('2021-12-01')) &
                race %in% c('Black', 'White', 'Hispanic') &
                Group == 'Chicago pop.',
              ],
            size = .5
  ) +
  xlab(NULL) +
  ylab('Proportion\n') +
  theme_bw(base_size = 25) +
  theme(legend.position = 'bottom'
  ) +
  scale_x_date(breaks = ymd(sprintf('%s-12-01', seq(1970, 2021, 5))),
               labels = seq(1970, 2021, 5),
               expand = expand_scale(add = -365),
               limits = ymd(c('1969-06-01', '2022-12-01'))
  ) +
  scale_y_continuous(expand = expand_scale())
