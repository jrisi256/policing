## compute officer proportions by race
##   (this uses unit assignments in dec 2004)
## s01_data_intro_map.R

make_plots <- function(date) {
district.props <- panel[
  month==date & unit <= 25][
    , .N,
    by = c('unit', 'officer_race_short')
    ]

## proportion of officers assigned to a unit that belong to race X
district.props[, prop.officerrace := N / sum(N), by = 'unit']

## drop categories other than black/hisp/white
district.props <- district.props[
  officer_race_short %in% ('officer_' %.% c('black', 'hisp', 'white')),
  ]

## merge in district compositions
district.composition <- districts[month == '2010-01-01',  # uses 2010 census
                                  .(district,
                                    di_prop_black,
                                    di_prop_hispanic,
                                    di_prop_white
                                  )
                                  ]

district.props <- district.composition[district.props,
                                       on = c(district = 'unit')
                                       ]

district.props[officer_race_short == 'officer_black',
               di_prop_coracial := di_prop_black
               ]

district.props[officer_race_short == 'officer_hisp',
               di_prop_coracial := di_prop_hispanic
               ]

district.props[officer_race_short == 'officer_white',
               di_prop_coracial := di_prop_white
               ]

## plot racial composition of district residents vs that of assigned officers
district.props[officer_race_short == 'officer_black', Race := 'Black']
district.props[officer_race_short == 'officer_hisp', Race := 'Hispanic']
district.props[officer_race_short == 'officer_white', Race := 'White']

ggplot(district.props,
       aes(x = di_prop_coracial,
           y = prop.officerrace,
           color = Race
       )
) +
  geom_point() +
  geom_abline(slope = 1, intercept = 0) +
  xlab('\nProportion of district civilians which are given race') +
  ylab('Proportion of officers\nof given race\nassigned to district\n') +
  ggtitle(paste0("Racial Composition of Officers\nvs. Racial Composition of Civilians\nby District for ", date)) +
  ## geom_abline(intercept = 0, slope = 1) +
  facet_wrap('Race') +
  theme_bw(base_size = 25) +
  theme(text = element_text(family = 'Helvetica'),
        legend.position = 'bottom',
        legend.box = 'vertical',
        legend.spacing = unit(0, 'in')
  ) +
  scale_color_manual(values = c(Black = '#A31F34',
                                Hispanic = '#CB963F',
                                White = '#4F6F9C'
  ),
  guide = FALSE
  ) +
  scale_x_continuous(breaks = c(0, .5, 1)) +
  theme(text = element_text(size = 15)) +
  ggsave(paste0(date, ".png"), device = "png", width = 14, height = 5.5)
}

dates <- c("2002-12-01", "2005-12-01", "2008-12-01", "2011-12-01", "2015-12-01")

plots <- purrr::map(dates, make_plots)