library(dplyr)
library(tidyr)
library(MASS)
library(stargazer)

district.props <-
  panel %>%
  filter(unit <= 25, officer_race_short %in% c("officer_black", "officer_white", "officer_hisp")) %>%
  count(month, unit, officer_race_short) %>%
  group_by(month, unit) %>%
  mutate(prcnt = n / sum(n)) %>%
  ungroup()

district.props.wide <-
  district.props %>%
  pivot_wider(id_cols = c("month", "unit"), names_from = "officer_race_short", values_from = c("prcnt", "n")) %>%
  mutate(log_black_officers = log(n_officer_black),
         log_white_officers = log(n_officer_white),
         log_hispanic_officers = log(n_officer_hisp))

district.props.join <-
  district.props.wide %>%
  full_join(dplyr::select(districts, month, district, officers_n, violent_cr, property_cr,
                          di_tot_pop, di_prop_hispanic, di_prop_black, di_prop_white,
                          di_tot_white, di_tot_black, di_tot_hispanic),
            by = c("unit" = "district", "month")) %>%
  mutate(log_tot_pop = log(di_tot_pop),
         log_black_pop = log(di_tot_black),
         log_hisp_pop = log(di_tot_hispanic),
         log_white_pop = log(di_tot_white),
         log_all_officers = log(officers_n)) %>%
  filter(across(everything(), ~ !is.na(.x)))

graph <-
  district.props.join %>%
  dplyr::select(prcnt_officer_black, di_prop_black, month, unit) %>%
  mutate(black_diff = prcnt_officer_black - di_prop_black) %>%
  rename(Officers = prcnt_officer_black, Population = di_prop_black, Parity = black_diff) %>%
  pivot_longer(cols = c("Officers", "Population", "Parity"))

graph1 <- graph %>% filter(name != "Parity")
graph2 <- graph %>% filter(name == "Parity")

ggplot(graph1, aes(x = month, y = value)) +
  geom_line(aes(color = name)) +
  facet_wrap(~unit) +
  theme_bw() +
  ylab("Proportion") +
  xlab("Year") +
  ggtitle("Proportion of Police Force Which is Black vs.Proportion Of Population Which is Black") +
  theme(legend.position = "bottom") +
  guides(color = guide_legend("Group"))

ggplot(graph2, aes(x = month, y = value)) +
  geom_line() +
  facet_wrap(~unit) +
  theme_bw() +
  ylab("Difference") +
  xlab("Year") +
  ggtitle("Parity of Black Officers and Black Civilian Population") +
  theme(legend.position = "bottom") +
  scale_y_continuous(limits = c(-0.8, 1))

# ggplot(join.diff, aes(x = black_diff, y = violent_cr)) + geom_point()

# assignments <- read.csv("~/capsule/code/assignments_with_outcomes.csv")

assignments.props <-
  assignments %>%
  group_by(month, unit) %>%
  summarise(stops = sum(stops_n_total, na.rm = T),
            arrests = sum(arrests_n_total, na.rm = T),
            force = sum(force_n_total, na.rm = T),
            black_stops = sum(stops_n_civilian_black, na.rm = T),
            black_arrests = sum(arrests_n_civilian_black, na.rm = T),
            black_force = sum(force_n_civilian_black, na.rm = T),
            hispanic_stops = sum(stops_n_civilian_hisp, na.rm = T),
            hispanic_arrests = sum(arrests_n_civilian_hisp, na.rm = T),
            hispanic_force = sum(force_n_civilian_hisp, na.rm = T),
            white_stops = sum(stops_n_civilian_white, na.rm = T),
            white_arrests = sum(arrests_n_civilian_white, na.rm = T),
            white_force = sum(force_n_civilian_white, na.rm = T)) %>%
  ungroup() %>%
  mutate(month = ymd(month))

join <-
  full_join(district.props.join, assignments.props, by = c("unit", "month")) %>%
  filter(across(everything(), ~ !is.na(.x)))

join.diff <-
  join %>%
  mutate(black_diff = prcnt_officer_black - di_prop_black,
         hispanic_diff = prcnt_officer_hisp - di_prop_hispanic,
         white_diff = prcnt_officer_white - di_prop_white,
         black_ratio = prcnt_officer_black / di_prop_black,
         hispanic_ratio = prcnt_officer_hisp / di_prop_hispanic,
         white_ratio = prcnt_officer_white / di_prop_white,
         black_flag = as.factor(if_else(black_diff >= 0, 0, 1)),
         hispanic_flag = as.factor(if_else(hispanic_diff >= 0, 0, 1)),
         white_flag = as.factor(if_else(white_diff >= 0, 0, 1)),
         unit = as.factor(unit),
         year = as.factor(year(month)),
         month = as.factor(month(month)))

prettyTable <-
  join.diff %>%
  as.data.frame() %>%
  dplyr::select(prcnt_officer_black, prcnt_officer_white, violent_cr, property_cr,
                di_prop_black, di_prop_white, stops, arrests, force,
                black_stops, black_arrests, black_force, white_stops, white_arrests, white_force,
                black_diff, white_diff)

stargazer(prettyTable,
          type = "html",
          covariate.labels = c("Percentage of Officers Which Are Black",
                               "Percentage of Officers Which Are White",
                               "Violent Crime Per Capita (Per 100,000)",
                               "Property Crime Per Capita (Per 100,000)",
                               "Proportion of Population Which Is Black",
                               "Proportion of Population Which Is White",
                               "Number of Stops",
                               "Number of Arrests",
                               "Number of Uses of Force",
                               "Number of Stops (Black Civilians)",
                               "Number of Arrests (Black Civilians)",
                               "Number of Uses of Force (Black Civilians)",
                               "Number of Stops (White Civilians)",
                               "Number of Arrests (White Civilians)",
                               "Number of Uses of Force (White Civilians)",
                               "Black Disparity",
                               "White Disparity"),
          out = "Descriptive.html")

nb.stops <-
  glm.nb(stops ~ month + year + unit + prcnt_officer_black + violent_cr + property_cr +
           log_all_officers + offset(log_tot_pop),
         data = join.diff)

nb.blackStops.prcnt <-
  glm.nb(black_stops ~ month + year + unit + prcnt_officer_black + violent_cr + property_cr +
           log_all_officers + offset(log_black_pop),
         data = join.diff)

nb.blackStops.diff <-
  glm.nb(black_stops ~ month + year + unit + black_diff + violent_cr + property_cr +
           log_all_officers + offset(log_black_pop),
         data = join.diff)

omitMonths <- paste0("month", 2:12)
omitYears <- paste0("year", 2012:2016)
omitUnits <- paste0("unit", 2:25)
note <- paste0("Fixed Effects Included for Month, Year, and Police Unit. Exposure variable for Model 1",
               "is the logged total population. The exposure variable for models 2 and 3",
               "is the logged Black population.")
stargazer(nb.stops, nb.blackStops.prcnt, nb.blackStops.diff,
          type = "html",
          omit = c(omitMonths, omitYears, omitUnits),
          out = "regression_tables.html",
          covariate.labels = c("Percentage of Officers Which Are Black",
                               "Black Parity",
                               "Violent Crime Per Capita",
                               "Property Crime Per Capita",
                               "Logged Total Number of Officers"),
          dep.var.labels = c("Stops of All Civilians", "Stops of Black Civilians"),
          notes = note,
          dep.var.caption = "Dependent Variables for Negative Binomial Regression")

nb.arrests <-
  glm.nb(arrests ~ month + year + unit + prcnt_officer_black + violent_cr + property_cr +
           log_all_officers + offset(log_tot_pop),
         data = join.diff)

nb.blackArrests.prcnt <-
  glm.nb(black_arrests ~ month + year + unit + prcnt_officer_black + violent_cr + property_cr +
           log_all_officers + offset(log_black_pop),
         data = join.diff)

nb.blackArrests.diff <-
  glm.nb(black_arrests ~ month + year + unit + black_diff + violent_cr + property_cr +
           log_all_officers + offset(log_black_pop),
         data = join.diff)

nb.force <-
  glm.nb(force ~ month + year + unit + prcnt_officer_black + violent_cr + property_cr +
           log_all_officers + offset(log_tot_pop),
         data = join.diff)

nb.blackForce.prcnt <-
  glm.nb(black_force ~ month + year + unit + prcnt_officer_black + violent_cr + property_cr +
           log_all_officers + offset(log_black_pop),
         data = join.diff)

nb.blackForce.diff <-
  glm.nb(black_force ~ month + year + unit + black_diff + violent_cr + property_cr +
           log_all_officers + offset(log_black_pop),
         data = join.diff)
